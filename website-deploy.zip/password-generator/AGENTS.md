﻿# DOX Framework - PASSWORD GENERATOR

## Purpose
This directory contains the PASSWORD GENERATOR web tool and its supporting documentation pages for TopWebTool.com.

## Ownership
- Parent: D:\TOPWEBTOOL\AGENTS.md (Root DOX Rail)
- Scope: All HTML pages, scripts, and assets within this directory

## Local Contracts
- All HTML pages must follow the SEO and accessibility standards defined in the root AGENTS.md
- Each page must include proper semantic HTML5 structure
- All interactive elements must have accessible names (aria-label or visible text)
- Meta tags, structured data, and canonical URLs must be present on all pages
- Performance optimizations must be applied (preconnect hints, font loading, etc.)

## Work Guidance
- Maintain consistent structure across all HTML files in this directory
- index.html is the primary tool page; other files are supporting articles
- All pages must pass accessibility and performance audits
- Content must be enriched to avoid "thin content" flags for AdSense

## Verification
- No automated verification framework is currently configured
- Manual audits should be performed using PageSpeed Insights and accessibility checkers

## Child DOX Index
- index.html - Primary tool interface
- `password-generator-best-practices.html` - Supporting article
- `password-generator-common-errors.html` - Supporting article
- `password-generator-future-trends.html` - Supporting article
- `password-generator-guide.html` - Supporting article
- `password-generator-optimization-tips.html` - Supporting article
